import React from 'react';

export default class AddressList extends React.Component{

  render(){
    return(
      <div> AddressList</div>
    )
  }
}