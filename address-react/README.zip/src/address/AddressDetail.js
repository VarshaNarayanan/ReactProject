import React from 'react';

export default class AddressDetail extends React.Component{

  render(){
    return(
      <div> AddressDetails</div>
    )
  }
}