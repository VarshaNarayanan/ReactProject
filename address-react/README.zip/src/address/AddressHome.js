import React from 'react';

export default class AddressHome extends React.Component{

  render(){
    return(
      <div> AddressHome</div>
    )
  }
}